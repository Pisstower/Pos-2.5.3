# Roadmap (post-2.5.3)

These items were tested after 2.5.3 but are *not* included in the rollback build. They remain planned for a future 2.5.x release (or 2.6.0) after stabilization and QA.

## UI — Receipts table
- Convert receipts list into a real table with `<thead>/<tbody>` and fixed column widths via `<colgroup>`.
- Align headers precisely over columns; right-align numeric columns.
- Sticky header in a scrollable container (`max-height` ~70vh).

## Sorting & Export
- Click-to-sort by **Date** and **Total** (ASC/DESC with visual arrow).
- Export current view to **CSV** (semicolon-delimited; BOM for Excel compatibility).

## Modal detail for receipt
- Open receipt detail in **modal window** (ESC/overlay click to close).
- Left: line items table; Right: summary card (DPH, total, payment method).
- Buttons: **Print**, Close.
- (Optional) integrate with `ReceiptPrintable` for PDF-friendly printout.

## PWA / Service Worker
- Register SW **only in production builds**.
- In dev: actively **unregister** any previous SW to avoid stale cache/blank screen.
- Re-validate offline shell once UI stabilizes.

## Next steps before re-release
- Add e2e smoke test (Cypress/Playwright) to catch blank-screen regressions.
- Manual QA checklist: build dev, hard reload, uninstall SW, production preview.
- Version bump to **2.5.4/2.5.5** only after passing QA.
