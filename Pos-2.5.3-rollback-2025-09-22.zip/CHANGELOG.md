## 2025-09-22 — Rollback to 2.5.3
- Reverted app to **2.5.3 (stable)** after issues observed in 2.5.5-modal (blank screen due to service worker cache interaction in dev).
- No schema changes vs. 2.5.3.
- `index.html` kept minimal; PWA SW registration remains **disabled for dev** in future branches until re-validated.

## 2.5.0

### Added
- **Sklad**: nový sloupec *On hand* (aktuální stav skladu) a oddělený sloupec *Velikost balení*.
- **Receptury**: produkty zvýrazněny tučně, komponenty zobrazují názvy surovin s množstvím a jednotkou.

### Changed
- **Import XLSX**: robustní parser cen (zvládá formáty `159,-`, `1 234,50 Kč`), ignoruje prázdné řádky.
- **Účtenky & Reporty**: datum a částky formátovány podle `cs-CZ`, lepší přehlednost tabulek.
- **Prodej**: tlačítko *Zaplatit* je pevně ukotveno dole v košíku.

### Fixed
- Nabídka po importu se ihned aktualizuje.
- Ceny z importu se již neukládají jako 0, pokud jsou v souboru vyplněny.
