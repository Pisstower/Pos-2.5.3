import React, { useMemo, useState } from 'react';

type Props = {
  total: number;
  onConfirm: (method: 'cash'|'card'|'other', paid: number, opts?: { print?: boolean }) => void;
  onClose: () => void;
};

const quickNotes = [100, 200, 500, 1000];

export default function PaymentModal({ total, onConfirm, onClose }: Props) {
  const [method, setMethod] = useState<'cash'|'card'|'other'>('cash');
  const [input, setInput] = useState<string>(''); // numeric string
  const paid = Number(input || 0);
  const change = useMemo(()=> Math.max(0, paid - total), [paid, total]);

  const press = (k:string) => {
    if (k === '⌫') { setInput(s => s.slice(0, -1)); return; }
    if (k === '⏎') { return; }
    if (k === '.' || k === ',') {
      setInput(s => s.includes('.') ? s : (s || '0') + '.');
      return;
    }
    if (/^\d$/.test(k)) setInput(s => (s==='0'? k : (s + k)));
  };
  const addQuick = (v:number) => setInput(s => {
    const cur = Number(s||0);
    return String(Number((cur + v).toFixed(2)));
  });
  const clear = () => setInput('');

  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.5)', zIndex: 9999}}>
      <div style={{maxWidth:720, margin:'6vh auto', background:'#fff', padding:16, borderRadius:12, boxShadow:'0 10px 30px rgba(0,0,0,.3)'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8}}>
          <h3 style={{margin:0}}>Platba</h3>
          <button onClick={onClose} aria-label="Zavřít">✕</button>
        </div>

        <p>Celkem: <strong>{total.toFixed(2)} Kč</strong></p>

        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
          <div>
            <div style={{marginBottom:8, display:'flex', gap:8}}>
              <button onClick={()=>setMethod('cash')} style={{fontWeight: method==='cash'?600:400}}>Hotově</button>
              <button onClick={()=>setMethod('card')} style={{fontWeight: method==='card'?600:400}}>Kartou</button>
              <button onClick={()=>setMethod('other')} style={{fontWeight: method==='other'?600:400}}>Jinak</button>
            </div>

            <div style={{marginBottom:8}}>
              <div>Uhrazena částka</div>
              <input inputMode="decimal" value={input} onChange={e=>setInput(e.target.value.replace(',', '.'))} style={{width:'100%', padding:8, fontSize:18}} placeholder="0" />
              <div style={{display:'flex', gap:8, flexWrap:'wrap', marginTop:8}}>
                {quickNotes.map(q => <button key={q} onClick={()=>addQuick(q)}>{q}</button>)}
                <button onClick={clear}>Vymazat</button>
              </div>
              <div style={{marginTop:8}}>Vrátit: <strong>{change.toFixed(2)} Kč</strong></div>
            </div>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:8, alignContent:'start'}}>
            {['7','8','9','4','5','6','1','2','3','0','.','⌫'].map(k => (
              <button key={k} style={{padding:'16px 0', fontSize:18}} onClick={()=>press(k)}>{k}</button>
            ))}
            <button style={{gridColumn:'1 / -1', padding:'12px 0', fontSize:16}} onClick={()=>press('⏎')}>Enter</button>
          </div>
        </div>

        <div style={{display:'flex', gap:8, marginTop:16, justifyContent:'flex-end'}}>
          <button onClick={()=>onConfirm(method, paid)} disabled={method==='cash' && paid < total}>Zaplatit</button>
          <button onClick={()=>onConfirm(method, paid, {print:true})} disabled={method==='cash' && paid < total}>Zaplatit & tisk</button>
        </div>
      </div>
    </div>
  );
}
