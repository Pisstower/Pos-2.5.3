import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Product, StockItem, Recipe } from '../../types';
import { setProducts, setStock, setRecipes } from '../../lib/storage';

type Parsed = {
  products: Product[];
  stock: (StockItem & { vatRate?: number })[];
  recipes: Recipe[];
  warnings: string[];
};


function parseMenu(ws: XLSX.WorkSheet, warnings: string[]): Product[] {
  const json = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
  if (!json.length) return [];
  let start = 0;
  const first = (json[0] || []).map((x: any)=> String(x||'').toLowerCase());
  if (first.some((x:string)=> x.includes('type') || x.includes('name') || x.includes('název') || x.includes('cena'))) start = 1;

  const out: Product[] = [];
  const wetAliases = ['wet','piti','pití','napoj','nápoj','drink','drinks','napoje','nápoje'];
  const dryAliases = ['dry','jidlo','jídlo','food','pokrm','pokrmy','jidelni','jídelní'];

  for (let i=start;i<json.length;i++) {
    const row = json[i];
    if (!row) continue;
    const allEmpty = !row.some((cell:any)=> (cell!==null && cell!==undefined && String(cell).trim()!==''));
    if (allEmpty) continue;

    const rawType = String(row[0] ?? '').trim().toLowerCase();
    const name = String(row[1] ?? '').trim();
    const priceCell = row[3];
    const priceGross = Number(priceCell);

    if (!name) { warnings.push(`menu řádek ${i+1}: přeskočeno (prázdný název)`); continue; }
    if (!isFinite(priceGross)) { warnings.push(`menu řádek ${i+1}: přeskočeno (neplatná cena)`); continue; }

    const type: 'dry'|'wet' = wetAliases.includes(rawType) ? 'wet' : 'dry';

    out.push({
      id: `p-${i}`,
      name,
      priceGross,
      vatRate: 0,
      type,
    });
  }
  if (!out.length) warnings.push('menu: nenačteny žádné položky – zkontroluj názvy sloupců / listu.');
  return out;
}
function parseSuroviny(ws: XLSX.WorkSheet, warnings: string[]): (StockItem & { vatRate?: number })[] {
  const json = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
  if (!json.length) return [];
  let start = 0;
  const first = (json[0] || []).map((x: any)=> String(x||'').toLowerCase());
  if (first.some((x:string)=> x.includes('dph') || x.includes('name') || x.includes('název'))) start = 1;

  const out: (StockItem & { vatRate?: number })[] = [];
  for (let i=start;i<json.length;i++) {
    const row = json[i];
    if (!row || row.every((v:any)=> (String(v||'').trim()===''))) continue;
    const name = String(row[1] ?? '').trim();
    if (!name) continue;
    let id = String(row[0] ?? name.toLowerCase().replace(/\s+/g,'-')).trim();
    id = id || name.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9_-]/g,'');
    const unit = String(row[2] ?? 'ks').trim() || 'ks';
    const qty = Number(row[3] ?? 0);
    const vatRate = Number(row[6] ?? 0); // sloupec G
    if (row[6] == null) warnings.push(`suroviny řádek ${i+1}: chybí DPH ve sloupci G → nastavuji 0 %`);
    out.push({ id, name, unit, qty: isFinite(qty)?qty:0, minQty: 0, vatRate: isFinite(vatRate) ? vatRate : 0 });
  }
  return out;
}

function parseReceptury(ws: XLSX.WorkSheet, warnings: string[], products: Product[], stock: StockItem[]): Recipe[] {
  const json = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
  if (!json.length) return [];
  let start = 0;
  const first = (json[0] || []).map((x: any)=> String(x||'').toLowerCase());
  if (first.some((x:string)=> x.includes('produkt') || x.includes('položka') || x.includes('recipe'))) start = 1;

  const pIndex = new Map(products.map(p => [p.name.trim().toLowerCase(), p.id]));
  const sIndex = new Map(stock.map(s => [s.id, s]));
  const sByName = new Map(stock.map(s => [s.name.trim().toLowerCase(), s]));

  const recMap = new Map<string, Recipe>();
  for (let i=start;i<json.length;i++) {
    const row = json[i];
    if (!row) continue;
    const prodName = String(row[0] ?? '').trim();
    const compRef = String(row[1] ?? '').trim();
    const amount = Number(row[2] ?? 0);
    if (!prodName || !compRef || !amount) continue;

    const productId = pIndex.get(prodName.toLowerCase());
    if (!productId) { warnings.push(`receptury řádek ${i+1}: produkt '${prodName}' nenalezen v menu`); continue; }

    let stockId = compRef;
    if (!sIndex.has(stockId)) {
      const byName = sByName.get(compRef.toLowerCase());
      if (byName) stockId = byName.id;
      else { warnings.push(`receptury řádek ${i+1}: surovina '${compRef}' nenalezena`); continue; }
    }

    const rec = recMap.get(productId) || { productId, components: [] };
    rec.components.push({ stockId, amount });
    recMap.set(productId, rec);
  }
  return Array.from(recMap.values());
}

export default function ImportXlsx() {
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const [error, setError] = useState<string>('');
  const [defaultVat, setDefaultVat] = useState<number>(21);
  const [inferVat, setInferVat] = useState<boolean>(true);

  const onFile = async (f: File) => {
    try {
      setError('');
      const buf = await f.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });

      const warnings: string[] = [];
      const wsMenu = wb.Sheets['menu'] || wb.Sheets['Menu'] || wb.Sheets['nabídka'] || wb.Sheets['Nabídka'] || wb.Sheets['nabidka'] || wb.Sheets['Nabidka'];
      const wsSuroviny = wb.Sheets['suroviny'] || wb.Sheets['Suroviny'];
      const wsReceptury = wb.Sheets['receptury'] || wb.Sheets['Receptury'];

      if (!wsMenu) throw new Error("Chybí list 'menu'");
      if (!wsSuroviny) throw new Error("Chybí list 'suroviny'");
      if (!wsReceptury) warnings.push("Chybí list 'receptury' — importuji bez receptur");

      const products = parseMenu(wsMenu, warnings);
      const stock = parseSuroviny(wsSuroviny, warnings);
      const recipes = wsReceptury ? parseReceptury(wsReceptury, warnings, products, stock) : [];

      setParsed({ products, stock, recipes, warnings });
    } catch (e:any) {
      setError(e.message || String(e));
    }
  };

  const apply = () => {
    if (!parsed) return;
    // Compute product vatRate
    let products = parsed.products.map(p => ({...p, vatRate: defaultVat}));
    if (inferVat && parsed.recipes.length && parsed.stock.length) {
      const sIdx = new Map(parsed.stock.map((s:any)=> [s.id, s.vatRate ?? defaultVat]));
      const byProd = new Map<string, number[]>();
      for (const r of parsed.recipes) {
        const rates = r.components.map(c => sIdx.get(c.stockId) ?? defaultVat);
        byProd.set(r.productId, rates);
      }
      products = products.map(p => {
        const arr = byProd.get(p.id);
        if (!arr || !arr.length) return p;
        const freq = new Map<number, number>();
        arr.forEach(v => freq.set(v, (freq.get(v)||0)+1));
        let best = defaultVat, bestN = -1;
        for (const [k,n] of freq) { if (n>bestN) {best=k; bestN=n;} }
        return {...p, vatRate: best};
      });
    }
    setProducts(products.filter(p=>p && p.name && isFinite(p.priceGross)) as any);
    setStock(parsed.stock as any);
    setRecipes(parsed.recipes);
    alert('Data importována.');
  };

  return (
    <div>
      <input type="file" accept=".xlsx,.xls" onChange={e=>{ const f=e.target.files?.[0]; if (f) onFile(f); }} />

      {error && <div style={{color:'red', marginTop:8}}>{error}</div>}

      {parsed && (
        <div style={{marginTop:12}}>
          <div style={{display:'flex', gap:12, alignItems:'center', marginTop:8}}>
            <label style={{display:'flex', alignItems:'center', gap:6}}>
              <input type="checkbox" checked={inferVat} onChange={e=>setInferVat(e.target.checked)} /> Vypočítat DPH produktu z receptur
            </label>
            <label style={{display:'flex', alignItems:'center', gap:6}}>
              Výchozí DPH produktu:
              <select value={defaultVat} onChange={e=>setDefaultVat(Number(e.target.value))}>
                <option value={21}>21 %</option>
                <option value={12}>12 %</option>
                <option value={0}>0 %</option>
              </select>
            </label>
          </div>

          <h4>Náhled importu</h4>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12}}>
            <div>
              <strong>Menu ({parsed.products.length})</strong>
              <ul>{parsed.products.slice(0,10).map(p=> <li key={p.id}>{p.name} — {p.priceGross} (DPH {p.vatRate}%)</li>)}</ul>
            </div>
            <div>
              <strong>Suroviny ({parsed.stock.length})</strong>
              <ul>{parsed.stock.slice(0,10).map(s=> <li key={s.id}>{s.name} [{s.unit}]</li>)}</ul>
            </div>
            <div>
              <strong>Receptury ({parsed.recipes.length})</strong>
              <ul>{parsed.recipes.slice(0,10).map(r=> <li key={r.productId}>{r.productId}: {r.components.length} položek</li>)}</ul>
            </div>
          </div>
          {!!parsed.warnings.length && (
            <details style={{marginTop:8}}>
              <summary>Varování ({parsed.warnings.length})</summary>
              <ul>{parsed.warnings.map((w,i)=> <li key={i}>{w}</li>)}</ul>
            </details>
          )}

          <div style={{marginTop:12}}>
            <button onClick={apply}>Importovat</button>
          </div>
        </div>
      )}
    </div>
  );
}