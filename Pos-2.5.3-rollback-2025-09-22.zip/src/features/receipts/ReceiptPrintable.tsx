import React from 'react';
import { CartItem } from '../../types';
import { getBusiness } from '../../lib/storage';

type Props = {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  total: number;
  paid: number;
};

export default function ReceiptPrintable({ id, createdAt, items, subtotal, tax, total, paid }: Props) {
  const b = getBusiness();
  return (
    <div className="receipt-paper">
      <h3>{b.companyName}</h3>
      <div className="muted">{b.address}{b.provozovna? ' • '+b.provozovna : ''}</div>
      <div className="muted">IČO: {b.ico}{b.dic? ' • DIČ: '+b.dic : ''}</div>
      <hr />
      <div className="row"><div>Účtenka</div><div>#{id}</div></div>
      <div className="row"><div>Datum</div><div>{new Date(createdAt).toLocaleString()}</div></div>
      <hr />
      {items.map(i => (
        <div key={i.productId} style={{marginBottom: 4}}>
          <div className="row"><div>{i.name} × {i.qty}</div><div>{i.total.toFixed(2)} {b.currency}</div></div>
        </div>
      ))}
      <hr />
      <div className="row"><div>Mezisoučet</div><div>{subtotal.toFixed(2)} {b.currency}</div></div>
      <div className="row"><div>DPH</div><div>{tax.toFixed(2)} {b.currency}</div></div>
      <div className="row"><strong>CELKEM</strong><strong>{total.toFixed(2)} {b.currency}</strong></div>
      <div className="row"><div>Uhrazeno</div><div>{paid.toFixed(2)} {b.currency}</div></div>
    </div>
  );
}
