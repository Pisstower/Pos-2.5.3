import React, { useEffect, useRef, useState } from 'react';
import { addReceipt } from '../../state/receipts';
import { CartItem } from '../../types';
import PaymentModal from '../payments/PaymentModal';
import { getBusiness } from '../../lib/storage';
import ReceiptPrintable from './ReceiptPrintable';
import { createRoot } from 'react-dom/client';

type Props = { open: boolean; onClose: () => void; cart: CartItem[]; };

export default function ReceiptModal({ open, onClose, cart }: Props) {
  const [preview, setPreview] = useState<string | null>(null);
  const printRootRef = useRef<HTMLElement | null>(null);

  useEffect(()=>{
    printRootRef.current = document.getElementById('print-root') as HTMLElement | null;
  }, []);

  if (!open) return null;

  const subtotal = cart.reduce((s, i) => s + i.total, 0);
  const b = getBusiness();
  const vat = (b.vatRate || 0) / 100;
  const tax = subtotal * vat;
  const total = subtotal + tax;

  const mountPrintable = (props: Parameters<typeof ReceiptPrintable>[0]) => {
    if (!printRootRef.current) return;
    printRootRef.current.innerHTML = '';
    const root = createRoot(printRootRef.current);
    root.render(<ReceiptPrintable {...props} />);
  };

  const finalize = (method: 'cash'|'card'|'other', paid: number, opts?: { print?: boolean }) => {
    const r = addReceipt({ items: cart, subtotal, tax, total, paymentMethod: method });
    mountPrintable({ id: r.id, createdAt: r.createdAt, items: cart, subtotal, tax, total, paid });
    setPreview(`#${r.id}  ${new Date(r.createdAt).toLocaleString()}\nCELKEM: ${total.toFixed(2)} ${b.currency}`);
    setTimeout(()=>{
      if (opts?.print && typeof window !== 'undefined' && typeof window.print === 'function') {
        try { window.print(); } catch {}
      }
      setPreview(null);
      if (printRootRef.current) printRootRef.current.innerHTML = '';
      onClose();
    }, 2000);
  };

  return (
    <>
      <PaymentModal total={total} onConfirm={finalize} onClose={onClose} />
      {preview && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.6)', zIndex: 10000, display:'flex', alignItems:'center', justifyContent:'center'}}>
          <div style={{background:'#fff', padding:16, borderRadius:8, width:360, whiteSpace:'pre-wrap', textAlign:'center'}}>
            {preview}
            <div style={{marginTop:8, fontSize:12, opacity:.7}}>(zavírám za 2 s)</div>
          </div>
        </div>
      )}
    </>
  );
}
