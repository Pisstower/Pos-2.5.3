export type Money = number;

export type Product = {
  id: string;
  name: string;
  priceGross: Money; // cena s DPH
  vatRate: number;   // sazba DPH (0/12/21)
  type: 'dry' | 'wet';
};

export type CartItem = {
  productId: string;
  name: string;
  qty: number;
  unitPrice: Money; // cena s DPH v době prodeje
  total: Money;
};

export type Receipt = {
  id: string; // e.g. 2025-000123
  createdAt: string; // ISO
  items: CartItem[];
  subtotal: Money;
  tax: Money;
  total: Money;
  paymentMethod: 'cash' | 'card' | 'other';
};

export type ImportPayload = {
  products: Product[];
};

export type StockItem = {
  id: string;
  name: string;
  unit: string; // 'kg','l','ks'
  qty: number; // velikost balení (legacy)
  packSize?: number; // alias pro čitelnost
  onHand?: number;   // aktuální stav skladu
  minQty?: number;
  vatRate?: number;
};

export type RecipeComponent = {
  stockId: string;
  amount: number; // in stock unit
};

export type Recipe = {
  productId: string;
  components: RecipeComponent[];
};

export type BusinessSettings = {
  companyName: string;
  ico: string;
  dic: string;
  provozovna: string;
  address: string;
  vatRate: number;
  currency: string;
};
