import React, { useState } from 'react';
import FoodDrinkView from '../views/FoodDrinkView';
import ReceiptsView from '../views/ReceiptsView';
import ReportsView from '../views/ReportsView';
import SkladView from '../views/SkladView';
import SettingsView from '../views/SettingsView';

type Tab = 'pos' | 'receipts' | 'reports' | 'stock' | 'settings';

export default function App() {
  const [tab, setTab] = useState<Tab>('pos');
  return (
    <div style={{height:'100vh', display:'flex', flexDirection:'column'}}>
      <div style={{flex:1, minHeight:0, paddingBottom:64}}>
        {tab==='pos' && <FoodDrinkView/>}
        {tab==='receipts' && <ReceiptsView/>}
        {tab==='reports' && <ReportsView/>}
        {tab==='stock' && <SkladView/>}
        {tab==='settings' && <SettingsView/>}
      </div>
      <footer style={{position:'fixed', left:0, right:0, bottom:0, background:'#111', color:'#fff', padding:8, zIndex:9999, boxShadow:'0 -4px 12px rgba(0,0,0,.2)'}}>
        <nav style={{display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:6}}>
          <button onClick={()=>setTab('pos')}>Prodej</button>
          <button onClick={()=>setTab('receipts')}>Účtenky</button>
          <button onClick={()=>setTab('reports')}>Reporty</button>
          <button onClick={()=>setTab('stock')}>Sklad</button>
          <button onClick={()=>setTab('settings')}>Nastavení</button>
        </nav>
      </footer>
    </div>
  );
}
