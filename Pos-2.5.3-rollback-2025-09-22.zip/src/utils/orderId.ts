/**
 * Generuje číslo účtenky ve formátu YYYY-XXXXX (sekvence resetuje každý rok).
 * Ukládá poslední hodnotu do localStorage, aby přetrvala mezi relacemi.
 */
export function nextOrderId(): string {
  const now = new Date();
  const year = now.getFullYear();
  const key = `pos-seq-${year}`;
  const last = parseInt(localStorage.getItem(key) || "0", 10) || 0;
  const next = last + 1;
  localStorage.setItem(key, String(next));
  const padded = String(next).padStart(5, "0");
  return `${year}-${padded}`;
}

export function peekOrderSequence(year: number = new Date().getFullYear()): number {
  const key = `pos-seq-${year}`;
  return parseInt(localStorage.getItem(key) || "0", 10) || 0;
}

export function resetOrderSequence(year: number = new Date().getFullYear()) {
  const key = `pos-seq-${year}`;
  localStorage.removeItem(key);
}
