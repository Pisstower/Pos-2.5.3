import React from "react";

type Props = {
  company?: string;
  ico?: string;
  provozovna?: string;
  adresa?: string;
  dic?: string;
};

export default function ReceiptHeader({
  company = "Hillbilly's Catering",
  ico = "IČO: 12345678",
  provozovna = "Provozovna: Karlovy Vary",
  adresa = "Adresa: Ulice 1, 360 01 Karlovy Vary",
  dic = "DIČ: CZ12345678",
}: Props) {
  return (
    <div style={{ textAlign: "center", fontSize: 12, lineHeight: 1.4 }}>
      <strong>{company}</strong><br />
      {ico}<br />
      {dic}<br />
      {provozovna}<br />
      {adresa}
      <hr />
    </div>
  );
}
