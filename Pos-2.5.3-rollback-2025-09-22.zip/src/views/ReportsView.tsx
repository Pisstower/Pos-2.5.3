import React, { useEffect, useMemo, useState } from 'react';
import { loadReceipts } from '../state/receipts';
import { Receipt } from '../types';
import { getBusiness } from '../lib/storage';

export default function ReportsView() {
  const [list, setList] = useState<Receipt[]>([]);
  useEffect(()=>{ setList(loadReceipts()); }, []);

  const fmt = new Intl.NumberFormat('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const byDay = useMemo(()=>{
    const m = new Map<string, {count:number, total:number}>();
    for (const r of list) {
      const d = new Date(r.createdAt);
      const key = d.toISOString().slice(0,10);
      const e = m.get(key) || {count:0, total:0};
      e.count += 1; e.total += r.total; m.set(key, e);
    }
    return Array.from(m.entries()).sort((a,b)=> a[0] < b[0] ? 1 : -1);
  }, [list]);

  const b = getBusiness();

  return (
    <div style={{padding:16}}>
      <h2>Reporty</h2>
      <h3>Denní souhrny</h3>
      <table width="100%" cellPadding={6}>
        <thead><tr><th>Datum</th><th>Počet účtenek</th><th>Tržba ({b.currency})</th></tr></thead>
        <tbody>
          {byDay.map(([d, e])=> (
            <tr key={d}><td>{d}</td><td>{e.count}</td><td style={{textAlign:'right'}}>{fmt.format(e.total)}</td></tr>
          ))}
          {byDay.length===0 && <tr><td colSpan={3} style={{textAlign:'center', opacity:.6}}>Zatím žádná data</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
