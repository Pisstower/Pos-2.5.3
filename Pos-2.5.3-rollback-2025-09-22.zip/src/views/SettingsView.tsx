import React, { useEffect, useState } from 'react';
import { getNumbering, setNumbering, getBusiness, setBusiness, getExport, setExport } from '../lib/storage';
import ImportXlsx from '../features/import/ImportXlsx';

type Num = ReturnType<typeof getNumbering>;
type Tab = 'receipt' | 'business' | 'import' | 'export' | 'other';

export default function SettingsView() {
  const [tab, setTab] = useState<Tab>('receipt');
  return (
    <div style={{padding:16, maxWidth:900}}>
      <h2>Nastavení</h2>

      <div style={{display:'flex', gap:8, borderBottom:'1px solid #eee', marginBottom:12}}>
        <button onClick={()=>setTab('receipt')} style={{fontWeight: tab==='receipt'?600:400}}>Účtenka</button>
        <button onClick={()=>setTab('business')} style={{fontWeight: tab==='business'?600:400}}>Firemní údaje</button>
        <button onClick={()=>setTab('import')} style={{fontWeight: tab==='import'?600:400}}>Import</button>
        <button onClick={()=>setTab('export')} style={{fontWeight: tab==='export'?600:400}}>Export</button>
        <button onClick={()=>setTab('other')} style={{fontWeight: tab==='other'?600:400}}>Ostatní</button>
      </div>

      {tab==='receipt' && <ReceiptNumberingSection />}
      {tab==='business' && <BusinessSettingsSection />}
      {tab==='import' && <ImportSection />}
      {tab==='export' && <ExportSection />}
      {tab==='other' && <OtherSection />}
    </div>
  );
}

function ReceiptNumberingSection() {
  const [cfg, setCfg] = useState<Num>(getNumbering());
  useEffect(()=>{ setCfg(getNumbering()); }, []);
  const save = () => { setNumbering(cfg); alert('Nastavení uloženo.'); };

  return (
    <div>
      <h3>Číslování účtenek</h3>
      <div style={{display:'grid', gridTemplateColumns:'200px 1fr', gap:8, alignItems:'center'}}>
        <label>Prefix</label>
        <input value={cfg.prefix} onChange={e=>setCfg({...cfg, prefix:e.target.value})} placeholder="např. HB" />
        <label>Zahrnout rok</label>
        <input type="checkbox" checked={cfg.includeYear} onChange={e=>setCfg({...cfg, includeYear:e.target.checked})} />
        <label>Oddělovač</label>
        <input value={cfg.sep} onChange={e=>setCfg({...cfg, sep:e.target.value || '-'})} maxLength={1} />
        <label>Počet číslic</label>
        <input type="number" min={1} max={10} value={cfg.pad} onChange={e=>setCfg({...cfg, pad: Math.max(1, Math.min(10, Number(e.target.value)||1))})} />
        <label>Další pořadové číslo</label>
        <input type="number" min={1} value={cfg.next} onChange={e=>setCfg({...cfg, next: Math.max(1, Number(e.target.value)||1)})} />
        <label>Poslední rok</label>
        <input type="number" value={cfg.lastYear} onChange={e=>setCfg({...cfg, lastYear: Number(e.target.value)||new Date().getFullYear()})} />
      </div>
      <div style={{marginTop:12, display:'flex', gap:8}}>
        <button onClick={save}>Uložit</button>
        <button onClick={()=>setCfg(getNumbering())}>Obnovit</button>
      </div>
      <p style={{marginTop:12, opacity:.7}}>
        Náhled: <code>
          {(cfg.prefix?cfg.prefix.replace(/\s+/g,'') + cfg.sep:'')}
          {cfg.includeYear? new Date().getFullYear() + cfg.sep : ''}
          {String(cfg.next).padStart(cfg.pad, '0')}
        </code>
      </p>
    </div>
  );
}

function BusinessSettingsSection() {
  const [b, setB] = React.useState(getBusiness());
  const save = () => { setBusiness(b); alert('Firemní údaje uloženy.'); };
  const reset = () => setB(getBusiness());

  return (
    <div>
      <h3>Firemní údaje</h3>
      <div style={{display:'grid', gridTemplateColumns:'200px 1fr', gap:8, alignItems:'center'}}>
        <label>Název firmy</label>
        <input value={b.companyName} onChange={e=>setB({...b, companyName:e.target.value})} />
        <label>IČO</label>
        <input value={b.ico} onChange={e=>setB({...b, ico:e.target.value})} />
        <label>DIČ</label>
        <input value={b.dic} onChange={e=>setB({...b, dic:e.target.value})} />
        <label>Provozovna</label>
        <input value={b.provozovna} onChange={e=>setB({...b, provozovna:e.target.value})} />
        <label>Adresa</label>
        <input value={b.address} onChange={e=>setB({...b, address:e.target.value})} />
        <label>Sazba DPH (%)</label>
        <input type="number" min={0} max={25} value={b.vatRate} onChange={e=>setB({...b, vatRate: Number(e.target.value)||0})} />
        <label>Měna</label>
        <input value={b.currency} onChange={e=>setB({...b, currency:e.target.value||'Kč'})} />
      </div>
      <div style={{marginTop:12, display:'flex', gap:8}}>
        <button onClick={save}>Uložit</button>
        <button onClick={reset}>Obnovit</button>
      </div>
    </div>
  );
}

function ImportSection() {
  return (
    <div>
      <h3>Import</h3>
      <p>Nahraj .xlsx soubor s listy <code>menu</code> (ceny s DPH), <code>suroviny</code> (sloupec G = sazba DPH) a <code>receptury</code>.</p>
      <ImportXlsx />
    </div>
  );
}

function ExportSection() {
  const [cfg, setCfg] = useState(getExport());
  const save = () => { setExport(cfg); alert('Export nastavení uloženo.'); };
  return (
    <div>
      <h3>Export</h3>
      <div style={{display:'grid', gridTemplateColumns:'200px 1fr', gap:8, alignItems:'center'}}>
        <label>Cílová cesta (hint)</label>
        <input value={cfg.path||''} onChange={e=>setCfg({...cfg, path: e.target.value})} placeholder="např. C:\\exports" />
        <label>Typ souboru</label>
        <select value={cfg.fileType} onChange={e=>setCfg({...cfg, fileType: e.target.value as any})}>
          <option value="json">JSON</option>
          <option value="csv">CSV</option>
          <option value="xlsx">XLSX</option>
        </select>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={save}>Uložit</button>
      </div>
    </div>
  );
}

function OtherSection() {
  return (
    <div>
      <h3>Ostatní</h3>
      <p>Rezervováno pro budoucí nastavení.</p>
    </div>
  );
}
