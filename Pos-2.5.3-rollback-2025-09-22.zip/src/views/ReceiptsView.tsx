import React, { useMemo, useState, useEffect, useRef } from 'react';
import { loadReceipts, clearReceipts } from '../state/receipts';
import { Receipt } from '../types';

function useReceipts() {
  const [list, setList] = useState<Receipt[]>([]);
  useEffect(()=>{ setList(loadReceipts()); }, []);
  return { list, refresh: ()=>setList(loadReceipts()) };
}

export default function ReceiptsView() {
  const { list, refresh } = useReceipts();
  const [qRaw, setQRaw] = useState('');
  const [q, setQ] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const t = useRef<number | null>(null);

  useEffect(()=>{
    if (t.current) window.clearTimeout(t.current);
    t.current = window.setTimeout(()=> setQ(qRaw), 250);
    return ()=> { if (t.current) window.clearTimeout(t.current); };
  }, [qRaw]);

  const fmtDate = new Intl.DateTimeFormat('cs-CZ', { dateStyle: 'short', timeStyle: 'short' });
  const fmt = new Intl.NumberFormat('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const filtered = useMemo(()=>{
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter(r => r.id.toLowerCase().includes(s));
  }, [q, list]);

  const toggle = (id:string) => setOpenId(prev => prev===id? null : id);

  return (
    <div style={{padding:16}}>
      <h2>Účtenky</h2>
      <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:8}}>
        <input placeholder="Hledat podle čísla..." value={qRaw} onChange={e=>setQRaw(e.target.value)} />
        <button onClick={()=>{ if(confirm('Smazat všechny účtenky?')) { clearReceipts(); refresh(); }}}>Vymazat vše</button>
        <button onClick={refresh}>Obnovit</button>
      </div>

      <table width="100%" cellPadding={6}>
        <thead>
          <tr><th>#</th><th>Datum</th><th>Celkem</th></tr>
        </thead>
        <tbody>
          {filtered.map(r=> (
            <React.Fragment key={r.id}>
              <tr onClick={()=>toggle(r.id)} style={{cursor:'pointer'}}>
                <td><code style={{fontWeight:600}}>{r.id}</code></td>
                <td>{fmtDate.format(new Date(r.createdAt))}</td>
                <td style={{textAlign:'right'}}>{fmt.format(r.total)} Kč</td>
              </tr>
              {openId===r.id && (
                <tr>
                  <td colSpan={3} style={{background:'#fafafa'}}>
                    <div style={{display:'flex', gap:12}}>
                      <div style={{flex:1}}>
                        <strong>Položky</strong>
                        <ul>
                          {r.items.map(i=> <li key={i.productId}>{i.name} × {i.qty} … {fmt.format(i.total)} Kč</li>)}
                        </ul>
                      </div>
                      <div style={{minWidth:200}}>
                        <div>DPH: {r.tax.toFixed(2)} Kč</div>
                        <div>Celkem: {fmt.format(r.total)} Kč</div>
                        <div>Platba: {r.paymentMethod}</div>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
          {filtered.length===0 && <tr><td colSpan={3} style={{textAlign:'center', opacity:.6}}>Žádné účtenky</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
