import React, { useEffect, useMemo, useState } from 'react';
import { loadStock, saveStock } from '../state/stock';
import { StockItem, Recipe } from '../types';
import { getRecipes, getProducts } from '../lib/storage';

type Tab = 'stock'|'recipes';

export default function SkladView() {
  const [tab, setTab] = useState<Tab>('stock');

  return (
    <div style={{padding:16}}>
      <h2>Sklad</h2>
      <div style={{display:'flex', gap:8, borderBottom:'1px solid #eee', marginBottom:12}}>
        <button onClick={()=>setTab('stock')} style={{fontWeight:tab==='stock'?600:400}}>Sklad</button>
        <button onClick={()=>setTab('recipes')} style={{fontWeight:tab==='recipes'?600:400}}>Receptury</button>
      </div>

      {tab==='stock' && <StockTab/>}
      {tab==='recipes' && <RecipesTab/>}
    </div>
  );
}

function StockTab() {
  const [list, setList] = useState<StockItem[]>([]);
  useEffect(()=>{ setList(loadStock()); }, []);

  const update = (id:string, field:keyof StockItem, val:any) => {
    setList(prev => prev.map(s => s.id===id ? {...s, [field]: val} : s));
  };

  const save = () => { saveStock(list); alert('Sklad uložen.'); };

  return (
    <div>
      <table width="100%" cellPadding={8} style={{borderCollapse:'collapse'}}>
        <thead style={{background:'#f6f6f6'}}><tr style={{borderBottom:'1px solid #e5e5e5'}}><th>SKU</th><th>Název</th><th>Jednotka</th><th>Velikost balení</th><th>On hand</th><th>Min</th></tr></thead>
        <tbody>
          {list.map(s => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td><input value={s.name} onChange={e=>update(s.id,'name',e.target.value)} /></td>
              <td><input value={s.unit} onChange={e=>update(s.id,'unit',e.target.value)} style={{width:60}}/></td>
              <td><input type="number" value={s.packSize ?? s.qty} onChange={e=>update(s.id,'packSize', Number(e.target.value)||0)} /></td>
              <td><input type="number" value={s.onHand ?? 0} onChange={e=>update(s.id,'onHand', Number(e.target.value)||0)} /></td>
              <td><input type="number" value={s.minQty||0} onChange={e=>update(s.id,'minQty', Number(e.target.value)||0)} /></td>
            </tr>
          ))}
          {list.length===0 && <tr><td colSpan={5} style={{textAlign:'center', opacity:.6}}>Sklad prázdný</td></tr>}
        </tbody>
      </table>
      <div style={{marginTop:8}}><button onClick={save}>Uložit</button></div>
    </div>
  );
}

function RecipesTab() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [productIndex, setProductIndex] = useState<Map<string, string>>(new Map());
  const [stockIndex, setStockIndex] = useState<Map<string, {name:string, unit:string}>>(new Map());

  useEffect(()=>{
    const list = getRecipes();
    setRecipes(list);
    const p = getProducts();
    setProductIndex(new Map(p.map(pp => [pp.id, pp.name])));
    const s = (window.localStorage.getItem('hillbilly:stock'));
    try {
      const parsed = s ? JSON.parse(s) : null;
      const items = parsed?.data || [];
      setStockIndex(new Map(items.map((it:any)=> [it.id, {name: it.name, unit: it.unit||'ks'}])));
    } catch { setStockIndex(new Map()); }
  }, []);


  useEffect(()=>{
    const list = getRecipes();
    setRecipes(list);
    const p = getProducts();
    setProductIndex(new Map(p.map(pp => [pp.id, pp.name])));
  }, []);

  return (
    <div>
      <table width="100%" cellPadding={8} style={{borderCollapse:'collapse'}}>
        <thead style={{background:'#f6f6f6'}}><tr><th>Produkt</th><th>Komponenty</th></tr></thead>
        <tbody>
          {recipes.map(r => (
            <tr key={r.productId}>
              <td style={{whiteSpace:'nowrap'}}><strong>{productIndex.get(r.productId) || r.productId}</strong></td>
              <td>
                <ul style={{margin:0, paddingLeft:16}}>
                  {r.components.map((c, idx) => { const meta = stockIndex.get(c.stockId); const label = meta? meta.name : c.stockId; const unit = meta? meta.unit : ''; return <li key={idx}><span style={{opacity:.9}}>{label}</span> × <strong>{c.amount}</strong> {unit}</li>; })}
                </ul>
              </td>
            </tr>
          ))}
          {recipes.length===0 && <tr><td colSpan={2} style={{textAlign:'center', opacity:.6}}>Žádné receptury</td></tr>}
        </tbody>
      </table>
      <p style={{marginTop:8, opacity:.7}}>Receptury se načítají z importu (.xlsx) – záložka Nastavení → Import.</p>
    </div>
  );
}