import React, { useMemo, useState } from 'react';
import { Product, CartItem } from '../types';
import ReceiptModal from '../features/receipts/ReceiptModal';
import { getProducts, EVENTS } from '../lib/storage';

export default function FoodDrinkView() {
  const [filter, setFilter] = useState<'all'|'dry'|'wet'>('all');
  const [q, setQ] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);

  const [products, setProductsState] = React.useState<Product[]>(()=> getProducts());

  React.useEffect(()=>{
    const reload = () => setProductsState(getProducts());
    window.addEventListener(EVENTS.products, reload);
    return () => window.removeEventListener(EVENTS.products, reload);
  }, []);

  const fallback: Product[] = [
    {id:'p1', name:'Burger', priceGross:159, vatRate:12, type:'dry'},
    {id:'p2', name:'Limo', priceGross:39, vatRate:12, type:'wet'},
    {id:'p3', name:'Fries', priceGross:59, vatRate:12, type:'dry'},
    {id:'p4', name:'Kafe', priceGross:49, vatRate:12, type:'wet'},
  ];

  const list = useMemo(()=>{
    const data = (products && products.length) ? products : fallback;
    return data.filter(p=> (filter==='all' || p.type===filter) && p.name.toLowerCase().includes(q.toLowerCase()));
  }, [products, filter, q]);

  const add = (p: Product) => {
    setCart(cur => {
      const idx = cur.findIndex(c => c.productId===p.id);
      if (idx>=0) {
        const copy = [...cur]; const it = copy[idx]; const qty = it.qty+1;
        copy[idx] = {...it, qty, total: qty*p.priceGross};
        return copy;
      }
      return [...cur, {productId:p.id, name:p.name, qty:1, unitPrice:p.priceGross, total:p.priceGross}];
    });
  };
  const inc = (id:string)=> setCart(c=> c.map(i=> i.productId===id? {...i, qty:i.qty+1, total:(i.qty+1)*i.unitPrice} : i));
  const dec = (id:string)=> setCart(c=> c.flatMap(i=> i.productId===id? (i.qty>1? [{...i, qty:i.qty-1, total:(i.qty-1)*i.unitPrice}] : []) : [i]));
  const sum = cart.reduce((s,i)=> s+i.total, 0);

  return (
    <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', height:'100%', minHeight:0}}>
      <div style={{display:'flex', flexDirection:'column', height:'100%'}}>
        <div style={{position:'sticky', top:0, zIndex:10, background:'#fff', padding:8, borderBottom:'1px solid #eee'}}>
          <input placeholder="Hledat..." value={q} onChange={e=>setQ(e.target.value)} />
          <div style={{display:'inline-flex', gap:6, marginLeft:8}}>
            <button onClick={()=>setFilter('all')} style={{fontWeight:filter==='all'?700:400}}>Vše</button>
            <button onClick={()=>setFilter('dry')} style={{fontWeight:filter==='dry'?700:400}}>Jídlo</button>
            <button onClick={()=>setFilter('wet')} style={{fontWeight:filter==='wet'?700:400}}>Pití</button>
          </div>
        </div>
        <div style={{padding:12, overflow:'auto', height:'100%'}}>
          <div style={{display:'grid', gap:12, gridTemplateColumns:'repeat(auto-fill, minmax(220px, 1fr))'}}>
            {list.map(p=> (
              <button key={p.id} onClick={()=>add(p)} style={{padding:'16px 14px', textAlign:'left'}}>
                <div style={{fontWeight:700}}>{p.name}</div>
                <div>{p.priceGross.toFixed(2)} Kč</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{display:'flex', flexDirection:'column', borderLeft:'1px solid #eee', height:'100%'}}>
        <div style={{position:'sticky', top:0, background:'#fff', padding:'8px 12px', borderBottom:'1px solid #eee'}}>Košík</div>
        <div style={{flex:1, overflow:'auto', padding:12, paddingBottom:72}}>
          {cart.map(i=> (
            <div key={i.productId} style={{display:'grid', gridTemplateColumns:'1fr auto auto', gap:8, alignItems:'center', marginBottom:6}}>
              <div>{i.name}</div>
              <div>× {i.qty}</div>
              <div>{i.total.toFixed(2)} Kč</div>
              <div style={{gridColumn:'1 / -1'}}>
                <button onClick={()=>dec(i.productId)}>-</button>{' '}
                <button onClick={()=>inc(i.productId)}>+</button>
              </div>
            </div>
          ))}
          {cart.length===0 && <div style={{opacity:.6}}>Košík je prázdný</div>}
        </div>
        <div style={{position:'fixed', right:0, left:'66.666%', bottom:56, background:'#fff', borderTop:'1px solid #eee', padding:12, display:'flex', justifyContent:'space-between', zIndex:9997}}>
          <strong>Celkem: {sum.toFixed(2)} Kč</strong>
          <button onClick={()=> setOpen(true)} disabled={!cart.length}>Zaplatit</button>
        </div>
      </div>

      <ReceiptModal open={open} cart={cart} onClose={()=>{ setOpen(false); setCart([]); }} />
    </div>
  );
}
