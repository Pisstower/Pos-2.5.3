const KEY_RECEIPTS = 'hillbilly:receipts';
const KEY_NUMCFG = 'hillbilly:receipt_numcfg';
const KEY_BUSINESS = 'hillbilly:business';
const KEY_STOCK = 'hillbilly:stock';
const KEY_RECIPES = 'hillbilly:recipes';
const KEY_PRODUCTS = 'hillbilly:products';
const KEY_EXPORT = 'hillbilly:exportcfg';

export type ReceiptNumbering = {
  prefix: string;
  includeYear: boolean;
  pad: number;
  sep: string;
  next: number;
  lastYear: number;
};
const DEFAULT_NUMCFG: ReceiptNumbering = {
  prefix: '',
  includeYear: true,
  pad: 6,
  sep: '-',
  next: 1,
  lastYear: new Date().getFullYear(),
};

export type Persisted<T> = { version: number; data: T };

export function loadJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && 'data' in parsed) {
      return (parsed as Persisted<T>).data;
    }
    return parsed as T;
  } catch {
    return fallback;
  }
}
export function saveJSON<T>(key: string, data: T) {
  const payload: Persisted<T> = { version: 1, data };
  localStorage.setItem(key, JSON.stringify(payload));
}

// events for live updates in same tab
export const EVENTS = {
  products: 'hillbilly:products:updated',
  stock: 'hillbilly:stock:updated',
  recipes: 'hillbilly:recipes:updated',
  receipts: 'hillbilly:receipts:updated',
};

// receipts
export function getReceipts(): import('../types').Receipt[] {
  return loadJSON(KEY_RECEIPTS, [] as import('../types').Receipt[]);
}
export function setReceipts(list: import('../types').Receipt[]) {
  saveJSON(KEY_RECEIPTS, list);
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(EVENTS.receipts));
}

// numbering
export function getNumbering() { return loadJSON<ReceiptNumbering>(KEY_NUMCFG, DEFAULT_NUMCFG); }
export function setNumbering(cfg: Partial<ReceiptNumbering>) {
  const cur = getNumbering();
  saveJSON(KEY_NUMCFG, { ...cur, ...cfg });
}
export function nextReceiptId(date = new Date()): string {
  const year = date.getFullYear();
  let cfg = getNumbering();
  if (cfg.includeYear && cfg.lastYear !== year) { cfg.next = 1; cfg.lastYear = year; }
  const n = cfg.next; cfg.next = n + 1; setNumbering(cfg);
  const parts: string[] = [];
  if (cfg.prefix) parts.push(cfg.prefix.replace(/\s+/g,''));
  if (cfg.includeYear) parts.push(String(year));
  parts.push(String(n).padStart(cfg.pad, '0'));
  return parts.join(cfg.sep);
}

// business
export function getBusiness(): import('../types').BusinessSettings {
  return loadJSON(KEY_BUSINESS, {
    companyName: "Hillbilly's Catering",
    ico: '',
    dic: '',
    provozovna: '',
    address: '',
    vatRate: 12,
    currency: 'Kč',
  } as import('../types').BusinessSettings);
}
export function setBusiness(cfg: Partial<import('../types').BusinessSettings>) {
  const cur = getBusiness(); saveJSON(KEY_BUSINESS, { ...cur, ...cfg });
}

// stock & recipes
export function getStock(): import('../types').StockItem[] { return loadJSON(KEY_STOCK, [] as any); }
export function setStock(items: import('../types').StockItem[]) { saveJSON(KEY_STOCK, items); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(EVENTS.stock)); }
export function getRecipes(): import('../types').Recipe[] { return loadJSON(KEY_RECIPES, [] as any); }
export function setRecipes(items: import('../types').Recipe[]) { saveJSON(KEY_RECIPES, items); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(EVENTS.recipes)); }

// products
export function getProducts(): import('../types').Product[] { return loadJSON(KEY_PRODUCTS, [] as any); }
export function setProducts(items: import('../types').Product[]) { saveJSON(KEY_PRODUCTS, items); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(EVENTS.products)); }

// export settings
export type ExportSettings = { path?: string; fileType: 'json'|'csv'|'xlsx' };
export function getExport(): ExportSettings { return loadJSON(KEY_EXPORT, { fileType: 'json' } as ExportSettings); }
export function setExport(cfg: Partial<ExportSettings>) {
  const cur = getExport(); saveJSON(KEY_EXPORT, { ...cur, ...cfg });
}
