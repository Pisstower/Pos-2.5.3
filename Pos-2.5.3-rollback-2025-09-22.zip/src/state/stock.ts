import { CartItem, Recipe, StockItem } from '../types';
import { getStock, setStock, getRecipes } from '../lib/storage';

export function loadStock(): StockItem[] { return getStock(); }
export function saveStock(list: StockItem[]) { setStock(list); }

export function decrementStockByReceipt(items: CartItem[]) {
  const stock = getStock();
  const recipes = getRecipes();
  if (!recipes.length) return;
  const index = new Map(stock.map(s => [s.id, s]));
  for (const ci of items) {
    const r = recipes.find(rx => rx.productId === ci.productId);
    if (!r) continue;
    for (const c of r.components) {
      const s = index.get(c.stockId);
      if (!s) continue;
      const current = typeof s.onHand === 'number' ? s.onHand : 0;
      s.onHand = Math.max(0, current - c.amount * ci.qty);
    }
  }
  setStock(Array.from(index.values()));
}
