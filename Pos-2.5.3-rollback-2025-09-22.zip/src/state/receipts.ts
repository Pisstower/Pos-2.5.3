import { Receipt } from '../types';
import { getReceipts, setReceipts, nextReceiptId } from '../lib/storage';
import { decrementStockByReceipt } from './stock';

export function loadReceipts(): Receipt[] { return getReceipts(); }

export function addReceipt(draft: Omit<Receipt,'id'|'createdAt'>): Receipt {
  const r: Receipt = { ...draft, id: nextReceiptId(), createdAt: new Date().toISOString() };
  const list = getReceipts();
  try { decrementStockByReceipt(r.items); } catch (e) { console.warn('Stock decrement failed', e); }
  list.unshift(r); setReceipts(list); return r;
}

export function clearReceipts() { setReceipts([]); }
